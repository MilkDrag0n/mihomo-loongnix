# Holosama UI

来源：[NextNapCatWebUI](https://github.com/bietiaop/NextNapCatWebUI)（MIT），锁定修订及参考组件见 `PROVENANCE.json`。这是从已确认的 NapCat 页面提取视觉规则、以 React + HeroUI 实现的公共组件包；不是 NapCat 的完整 fork。版本以 `package.json` 和消费项目锁文件为准。

## 统一技术栈

React 19、TypeScript、HeroUI 2、Tailwind 4、Vite 7。HoloBot 和 Mihomo 使用同一套主题、侧栏、卡片、统计、仪表、按钮、下拉框和弹窗，不再维护 Vue 适配层。路由、API、鉴权及业务状态由各应用提供。组件不携带服务端地址或密钥。

## 接入新面板

1. 以 React/TypeScript Vite 项目起步。安装 React、HeroUI、Framer Motion、Tailwind 4 及 Vite 插件，确切兼容组合参考两个已接入项目的锁文件。
2. 在本目录运行 `npm test && npm pack`，把产物放到消费项目 `vendor/`，执行 `npm install ./vendor/holosama-ui-0.2.2.tgz`。本包不需要公网 npm 发布或额外服务。
3. Vite 使用 `react()` 和 `tailwindcss()` 插件，开发模式 `optimizeDeps.include` 加入 `@heroui/react` 和 `framer-motion`。Tailwind 配置启用 `heroui()` 插件；CSS 显式扫描 `@heroui/theme/dist` 与本包 `react/`，参照现有 `tailwind.config.js` 和 `src/style.css`。
4. 入口包裹 `HeroUIProvider`，导入公共主题，给 body 加 `holo-app`。以下为最小页面组件：

```tsx
import '@holosama/ui/theme.css';
import {HeroUIProvider, Sidebar, Card, Stat, Gauge, Button, Select} from '@holosama/ui/react';

document.body.classList.add('holo-app');
export function Dashboard() {
  return <HeroUIProvider>
    <Card><Gauge label="CPU 占用" value={undefined} /></Card>
    <Stat label="活动连接" value="—" />
    <Button onClick={() => console.info('接入自己的刷新函数')}>刷新状态</Button>
  </HeroUIProvider>;
}
```

`Sidebar` 的 children 接收业务 `NavLink`，footer 接收退出登录等操作；`collapsed/onCollapse` 管理折叠。`Select` 接收 `options/value/onValueChange` 并须提供 `aria-label`。`Card/Button/Select` 基于真实 HeroUI 组件；Modal、Input 等直接从包导出。

## 主题和数据

- `--holo-*` 是唯一颜色和圆角来源。深色为默认主题；`ThemeButton` 同步 HTML 的 `data-holo-theme`、`.dark` 及本域名 localStorage。不同域名不共享存储。
- 复用类包括 `holo-brand`、`holo-nav-link`、`holo-topbar`、`holo-stats`、`holo-fields`、`holo-status`。页面网格和业务特有布局由应用维护。
- Gauge 的未知数值传 `null/undefined`，显示“—”；总量未知用 `max={null}`，不伪造占用百分比。侧栏图标、头像由业务选用；预览中的第三方角色图不打包。
- 不复制 NapCat 鉴权、QQ 逻辑和运行配置；服务器现有 cookie、CSRF、固定动作接口继续负责权限边界。

## 升级与验证

修改公共包后递增版本、重新打包，同时更新两个消费项目的 vendor 包和 npm 锁文件。`npm test` 验证数值及存储边界；消费端运行类型检查、构建及模拟 API 的 UI 回归，覆盖键盘选择、主题、窄屏、鉴权和业务状态。保留 `licenses/NextNapCatWebUI-MIT.txt` 和来源记录。

服务器公共源码：`/home/server/services/ui-kit`。消费端：`/home/server/services/holobot/HoloBot-dashboard/web`、`/home/server/services/mihomo/source/web`。无需启动第三个 UI 服务。
