/** Missing or invalid observations stay unknown; gauges never turn them into 0. */
export function gauge(value, max = 100) {
  const known = typeof value === 'number' && Number.isFinite(value) && value >= 0;
  const bounded = known && typeof max === 'number' && Number.isFinite(max) && max > 0;
  return {known, percent: bounded ? Math.min(100, value / max * 100) : null};
}
export function readTheme(storage, key = 'holosama-theme') {
  try { return storage?.getItem(key) === 'light' ? 'light' : 'dark'; } catch { return 'dark'; }
}
export function applyTheme(theme, storage, element, key = 'holosama-theme') {
  const value = theme === 'light' ? 'light' : 'dark';
  element.dataset.holoTheme = value;
  element.classList?.toggle("dark", value === "dark");
  try { storage?.setItem(key, value); } catch { /* Private mode can deny storage. */ }
  return value;
}
