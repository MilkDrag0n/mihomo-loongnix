export function gauge(value: number | null | undefined, max?: number | null): {known: boolean; percent: number | null};
export function readTheme(storage?: Pick<Storage,'getItem'> | null, key?: string): 'light' | 'dark';
export function applyTheme(theme: string, storage: Pick<Storage,'setItem'> | null | undefined, element: HTMLElement, key?: string): 'light' | 'dark';
