import {test} from 'node:test';
import assert from 'node:assert/strict';
import {gauge, readTheme, applyTheme} from './core.js';
test('unknown and partial metrics never imply zero usage',()=>{
 for(const v of [undefined,null,NaN,Infinity,-1])assert.deepEqual(gauge(v),{known:false,percent:null});
 assert.deepEqual(gauge(0),{known:true,percent:0});
 assert.deepEqual(gauge(42,null),{known:true,percent:null});
 assert.equal(gauge(800).percent,100);
 assert.equal(gauge(25,50).percent,50);
});
test('blocked storage still permits an accessible applied theme',()=>{
 const storage={getItem(){throw Error('denied')},setItem(){throw Error('denied')}};
 assert.equal(readTheme(storage),'dark');const el={dataset:{}};
 assert.equal(applyTheme('light',storage,el),'light');assert.equal(el.dataset.holoTheme,'light');
});
