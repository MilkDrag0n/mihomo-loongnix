import {
  useEffect,
  useState,
  type ReactNode,
  type ComponentProps,
} from "react";
import {
  Card as HeroCard,
  Button as HeroButton,
  Select as HeroSelect,
  SelectItem,
  HeroUIProvider,
  type CardProps,
  type ButtonProps,
} from "@heroui/react";
export {
  HeroUIProvider,
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Input,
  Textarea,
  Switch,
  Chip,
  Tabs,
  Tab,
} from "@heroui/react";
import { gauge, readTheme, applyTheme } from "../src/core.js";
export function Card({ className = "", ...props }: CardProps) {
  return (
    <HeroCard
      as="section"
      shadow="none"
      className={`holo-card ${className}`}
      {...props}
    />
  );
}
export function Stat({
  label,
  value,
  unit,
}: {
  label: string;
  value: ReactNode;
  unit?: string;
}) {
  return (
    <div className="holo-card holo-stat">
      <strong>
        {value}
        <small>{unit}</small>
      </strong>
      <span>{label}</span>
    </div>
  );
}
export function Gauge({
  value,
  max = 100,
  label,
  unit = "%",
  digits = 0,
}: {
  value?: number | null;
  max?: number | null;
  label: string;
  unit?: string;
  digits?: number;
}) {
  const { known, percent } = gauge(value, max);
  return (
    <div
      className="holo-gauge"
      role="img"
      aria-label={`${label}：${known ? value!.toFixed(digits) + unit : "暂无数据"}`}
    >
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <circle className="holo-gauge-track" cx="60" cy="60" r="49" />
        {percent !== null && (
          <>
            <circle
              className="holo-gauge-arc"
              cx="60"
              cy="60"
              r="49"
              strokeDasharray={`${percent * 3.079} 308`}
            />
            {percent > 0 && (
              <circle
                className="holo-gauge-tip"
                cx="60"
                cy="60"
                r="49"
                strokeDasharray="1 308"
              />
            )}
          </>
        )}
      </svg>
      <div>
        <small>{label}</small>
        <strong>
          {known ? value!.toFixed(digits) : "—"}
          <em>{known ? unit : ""}</em>
        </strong>
      </div>
    </div>
  );
}
export function ThemeButton() {
  const [theme, setTheme] = useState(() =>
    readTheme(typeof localStorage === "undefined" ? null : localStorage),
  );
  useEffect(() => {
    applyTheme(
      theme,
      typeof localStorage === "undefined" ? null : localStorage,
      document.documentElement,
    );
  }, [theme]);
  return (
    <button
      type="button"
      className="holo-theme-toggle"
      aria-label={theme === "dark" ? "切换浅色主题" : "切换深色主题"}
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
    >
      <span aria-hidden="true">☾</span> 切换主题
    </button>
  );
}

export function Button({
  variant = "default",
  size = "default",
  disabled,
  className = "",
  ...props
}: Omit<ButtonProps, "variant" | "size"> & {
  disabled?: boolean;
  variant?: "default" | "outline" | "ghost" | "danger";
  size?: "default" | "sm" | "icon";
}) {
  return (
    <HeroButton
      {...props}
      isDisabled={disabled}
      isIconOnly={size === "icon"}
      size={size === "sm" ? "sm" : "md"}
      radius="md"
      variant={
        variant === "outline"
          ? "bordered"
          : variant === "ghost"
            ? "light"
            : "flat"
      }
      color="danger"
      className={`button button-${variant === "default" ? "primary" : variant} ${size === "sm" ? "button-small" : size === "icon" ? "button-icon" : ""} ${className}`}
    />
  );
}
export type SelectOption = { value: string; label: string; disabled?: boolean };
export function Select({
  value,
  onValueChange,
  options,
  placeholder = "请选择",
  disabled,
  className = "",
  required,
  name,
  ...props
}: {
  value: string;
  onValueChange: (value: string) => void;
  options: readonly SelectOption[];
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  required?: boolean;
  name?: string;
  id?: string;
  "aria-label"?: string;
  "aria-labelledby"?: string;
  "aria-describedby"?: string;
  "aria-invalid"?: ComponentProps<"button">["aria-invalid"];
}) {
  return (
    <HeroSelect
      disableAnimation
      // Opening after focus scroll must not immediately dismiss the list.
      popoverProps={{disableAnimation: true, shouldCloseOnScroll: false}}
      {...props}
      name={name}
      aria-label={props["aria-label"]}
      isRequired={required}
      isDisabled={disabled || !options.some((o) => !o.disabled)}
      selectedKeys={value ? [value] : []}
      disabledKeys={options.filter((o) => o.disabled).map((o) => o.value)}
      onSelectionChange={(keys) => {
        if (keys !== "all") {
          const key = [...keys][0];
          if (key !== undefined) onValueChange(String(key));
        }
      }}
      placeholder={placeholder}
      disallowEmptySelection
      size="sm"
      variant="bordered"
      className={`holo-select ${className}`}
      classNames={{
        trigger: "holo-select-trigger",
        value: "holo-select-value",
        popoverContent: "holo-select-popover",
      }}
    >
      {options.map((o) => (
        <SelectItem key={o.value} textValue={o.label}>
          {o.label}
        </SelectItem>
      ))}
    </HeroSelect>
  );
}
export function Sidebar({
  name,
  children,
  footer,
  collapsed,
  onCollapse,
}: {
  name: string;
  children: ReactNode;
  footer?: ReactNode;
  collapsed?: boolean;
  onCollapse?: () => void;
}) {
  return (
    <aside className="navigation">
      <button
        type="button"
        className="brand nav-toggle"
        onClick={onCollapse}
        aria-expanded={!collapsed}
        aria-label={collapsed ? "展开侧边栏" : "收起侧边栏"}
      >
        <span className="holo-brand">{name}</span>
      </button>
      <nav aria-label="主要导航">{children}</nav>
      <div className="nav-bottom">
        <ThemeButton />
        {footer}
      </div>
    </aside>
  );
}
